﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace FoodOrderApp
{
    public partial class Regisztracio : Form
    {
        public Regisztracio()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void Regisztracio_FormClosed(object sender, FormClosedEventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Hide();
            f1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                label6.Text = "Megadott jelszó: " + textBox2.Text;
            }
            else {
                MessageBox.Show("Még nincs megadva jelszó");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            

            if (textBox1.Text != "" && textBox2.Text != ""&& comboBox1.SelectedIndex>=0)
            {
                string cmbitem = comboBox1.SelectedItem.ToString();

                DB db = new DB();
                db.openconnection();
                SQLiteCommand cmd = new SQLiteCommand("insert into belepes(felhnev, jelszo, szerepkor) values ('" + textBox1.Text + "', '" + textBox2.Text + "', '" + cmbitem + "')", db.GetConnection());
                cmd.ExecuteNonQuery();
                db.closeconnection();
                textBox1.Text = "";
                textBox2.Text = "";
                label6.Text = "";
               


            }
            else {
                MessageBox.Show("Kérlek tölts ki minden mezőt! ");
            }
        }
    }
}
