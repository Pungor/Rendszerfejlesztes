﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
namespace FoodOrderApp
{
    public partial class Rendel : Form
    {
        DB db = new DB();
        SQLiteDataAdapter sda;
        DataTable dt;
        SQLiteCommand cmd;
        
        public Rendel(string username)
        {
            InitializeComponent();
            label10.Text = username;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void Rendel_FormClosed(object sender, FormClosedEventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex > 0)
            {
                int index1 = e.RowIndex;// lekérjük a sor indexét
                DataGridViewRow selectedRow1 = dataGridView1.Rows[index1];
                textBox1.Text = selectedRow1.Cells[1].Value.ToString();
                textBox2.Text = selectedRow1.Cells[7].Value.ToString();
                textBox3.Text = selectedRow1.Cells[3].Value.ToString();
                //textBox5.Text = selectedRow1.Cells[5].Value.ToString();
                textBox6.Text = selectedRow1.Cells[5].Value.ToString();
                textBox8.Text = selectedRow1.Cells[8].Value.ToString();
                textBox9.Text = selectedRow1.Cells[9].Value.ToString();

            }
            if (e.ColumnIndex == 0)
            {
                int index = e.RowIndex;// lekérjük a sor indexét
                DataGridViewRow selectedRow = dataGridView1.Rows[index];
                textBox1.Text = selectedRow.Cells[1].Value.ToString();
                textBox2.Text = selectedRow.Cells[7].Value.ToString();
                textBox3.Text = selectedRow.Cells[3].Value.ToString();
              //  textBox5.Text = selectedRow.Cells[5].Value.ToString();
                textBox6.Text = selectedRow.Cells[5].Value.ToString();
                textBox8.Text = selectedRow.Cells[8].Value.ToString();
                textBox9.Text = selectedRow.Cells[9].Value.ToString();

                DialogResult result = MessageBox.Show("Kosárba szeretnéd helyezni?", "Figyelem", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    DB db = new DB();
                    db.openconnection();
                    SQLiteCommand cmd = new SQLiteCommand("insert into kosar (etel, kosarar, kosaretterem, kosaridoszak, kosarakcio, elkeszites, username) values ('" + textBox1.Text + "', '" + textBox3.Text + "', '" + textBox9.Text + "', '" + textBox6.Text + "', '" + textBox2.Text + "', '" + textBox8.Text + "', '" + label10.Text + "')", db.GetConnection());
                    cmd.ExecuteNonQuery();
                    db.closeconnection();
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                 
                 //   textBox5.Text = "";
                    textBox6.Text = "";
                    textBox8.Text = "";
                    textBox9.Text = "";
                    MessageBox.Show("Kosárba helyezve ");


                    megjelenit();
                }
                

            }
        }
        private void megjelenit()
        {


            cmd = new SQLiteCommand("select * from etlap", db.GetConnection());
            sda = new SQLiteDataAdapter(cmd);
            dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            db.closeconnection();

            //set autosize mode
            for (int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            }

            // Oszlopok fejlécének középre igazítása
            for (int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                dataGridView1.Columns[i].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

            //adatok sorok háttérszíne minden 2. sornál
            for (int i = 0; i < dataGridView1.RowCount; i += 2)
            {
                dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.LightGreen;
            }
            //Fejlécek elnevezése
            dataGridView1.Columns[0].HeaderText = "Művelet";
            dataGridView1.Columns[1].HeaderText = "Ételnév";
            dataGridView1.Columns[2].HeaderText = "Leírás";
            dataGridView1.Columns[3].HeaderText = "Ár";
            dataGridView1.Columns[4].HeaderText = "Allergének";
         //   dataGridView1.Columns[5].HeaderText = "Étterem";
            dataGridView1.Columns[5].HeaderText = "Időszak";
            dataGridView1.Columns[6].HeaderText = "Összetevők";
            dataGridView1.Columns[7].HeaderText = "Akció (%)";
            dataGridView1.Columns[8].HeaderText = "Elkészítés (perc)";
            dataGridView1.Columns[9].HeaderText = "Étterem azonosító";
            //Fejléc formázása
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 6, FontStyle.Bold);
            //Fejléc háttérszíne
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.LightBlue;
            dataGridView1.EnableHeadersVisualStyles = false;
            //adatok középre igazítása
            for (int i = 1; i < dataGridView1.Columns.Count; i++)
            {
                this.dataGridView1.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }


        }

        private void button11_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";

         //   textBox5.Text = "";
            textBox6.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            megjelenit();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox7.Text == "")
            {
                MessageBox.Show("Állítson be keresószót! ");
            }
            else
            {
                db.openconnection();
                cmd = new SQLiteCommand("select * from etlap where leiras='" + textBox7.Text + "'", db.GetConnection());
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                sda = new SQLiteDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                db.closeconnection();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
            //    textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox4.Text == "")
            {
                MessageBox.Show("Állítson be keresószót! ");
            }
            else
            {
                db.openconnection();
                cmd = new SQLiteCommand("select * from etlap where etelnev='" + textBox4.Text + "'", db.GetConnection());
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                sda = new SQLiteDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                db.closeconnection();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
          //      textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
                Kosar kos = new Kosar(label10.Text);
                this.Hide();
                kos.Show();


        }
    }
}
